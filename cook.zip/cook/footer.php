<footer>
    <div class="container">
        <p>&copy; 2025 Kuvajmo | By: Dejana Zorić | Email: dejana.zoric@apeiron-edu.eu<a href="mailto:[dejana.zoric@apeiron-edu.eu]">[dejana.zoric@apeiron-edu.eu]</a></p>
    </div>
</footer>
</body>
</html>